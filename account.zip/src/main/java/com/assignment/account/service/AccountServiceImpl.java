package com.assignment.account.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.account.entity.AccountDetails;
import com.assignment.account.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService{

	@Autowired
	AccountRepository accountRepo;
	
	public void save(AccountDetails account) {
		try {
			accountRepo.save(account);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
