package com.assignment.account.service;

import com.assignment.account.entity.AccountDetails;

public interface AccountService {

	void save(AccountDetails account);
}
